class Head:

    header = {"Content-Type": "application/json"}
