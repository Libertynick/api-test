class Payloads:
    """Отправляемые данные"""

    debtor_account_vodokomfort = '0014403847'
    inn_vodokomfort = '7705238125'
    debtor_account_for_get_customer_by_number = '14480074'
